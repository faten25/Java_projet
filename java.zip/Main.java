import javax.swing.*;

public class Main {
    public static void main(String[] args) {

        ArbreGenealogique arbreGenealogique = new ArbreGenealogique();

        arbreGenealogique.setVisible(true);

    }
}
