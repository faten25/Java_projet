import java.util.HashSet;
import java.util.Set;

public class Personne {
    private String nom;
    private int age;
    public String prenom;
    public char sexe;
    public DateUtil dateNaissance;
    public DateUtil dateMort;
    public Personne pere;
    public Personne mere;
    public Set<Personne> enfants;

    public Personne(String nom, int age, String prenom, char sexe, DateUtil dateNaissance, DateUtil dateMort) {
        this.nom = nom;
        this.age = age;
        this.prenom = prenom;
        this.sexe = sexe;
        this.dateNaissance = dateNaissance;
        this.dateMort = dateMort;
        this.enfants = new HashSet<>();
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String toString() {
        return "Nom " + nom + ", Âge " + age + ", Prénom " + prenom + ", Sexe " + sexe + ", Date de Naissance " + dateNaissance + ", Date de Mort " + dateMort;
    }

    public void afficher() {
        System.out.println(this);
    }

    public Set<Personne> trouverFreresEtSoeurs() {
        Set<Personne> freresEtSoeurs = new HashSet<>();
        if (pere != null) {
            Personne[] enfantsPere = pere.enfants.toArray(new Personne[0]);
            for (int i = 0; i < enfantsPere.length; i++) {
                Personne enfant = enfantsPere[i];
                if (!enfant.equals(this)) {
                    freresEtSoeurs.add(enfant);
                }
            }
        }
        if (mere != null) {
            Personne[] enfantsMere = mere.enfants.toArray(new Personne[0]);
            for (int i = 0; i < enfantsMere.length; i++) {
                Personne enfant = enfantsMere[i];
                if (!enfant.equals(this)) {
                    freresEtSoeurs.add(enfant);
                }
            }
        }
        return freresEtSoeurs;
    }

    public Set<Personne> trouverCousins() {
        Set<Personne> cousins = new HashSet<>();
        if (pere != null) {
            Set<Personne> freresEtSoeursPere = pere.trouverFreresEtSoeurs();
            Personne[] onclesTantesPere = freresEtSoeursPere.toArray(new Personne[0]);
            for (int i = 0; i < onclesTantesPere.length; i++) {
                Personne oncleTante = onclesTantesPere[i];
                Personne[] enfantsOncleTante = oncleTante.enfants.toArray(new Personne[0]);
                for (int j = 0; j < enfantsOncleTante.length; j++) {
                    cousins.add(enfantsOncleTante[j]);
                }
            }
        }
        if (mere != null) {
            Set<Personne> freresEtSoeursMere = mere.trouverFreresEtSoeurs();
            Personne[] onclesTantesMere = freresEtSoeursMere.toArray(new Personne[0]);
            for (int i = 0; i < onclesTantesMere.length; i++) {
                Personne oncleTante = onclesTantesMere[i];
                Personne[] enfantsOncleTante = oncleTante.enfants.toArray(new Personne[0]);
                for (int j = 0; j < enfantsOncleTante.length; j++) {
                    cousins.add(enfantsOncleTante[j]);
                }
            }
        }
        return cousins;
    }
}