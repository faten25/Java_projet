import java.util.*;

public class Arbre {
    public Date creation;
    public String nom;
    public Set<Personne> listePersonne;

    public Arbre(String nom) {
        this.creation = new Date();
        this.nom = nom;
        this.listePersonne = new HashSet<>();
    }

    public void ajouterPersonne(Personne p) {
        listePersonne.add(p);
    }

    public Personne trouverPersonneParPrenom(String prenom) {
        for (Iterator<Personne> it = listePersonne.iterator(); it.hasNext();) {
            Personne p = it.next();
            if (p.prenom.equals(prenom)) {
                return p;
            }
        }
        return null;
    }

    public void afficherArbre() {
        for (Iterator<Personne> it = listePersonne.iterator(); it.hasNext();) {
            Personne p = it.next();
            p.afficher();
        }
    }

    public void afficherAncetres(String prenom) {
        Personne personne = trouverPersonneParPrenom(prenom);
        if (personne != null) {
            Personne p = personne;
            while (p.pere != null || p.mere != null) {
                if (p.pere != null) {
                    System.out.println("Père : " + p.pere.prenom);
                    p = p.pere;
                }
                if (p.mere != null) {
                    System.out.println("Mère : " + p.mere.prenom);
                    p = p.mere;
                }
            }
        }
    }

    public void afficherFreresEtSoeurs(String prenom) {
        Personne personne = trouverPersonneParPrenom(prenom);
        if (personne != null) {
            for (Iterator<Personne> it = listePersonne.iterator(); it.hasNext();) {
                Personne p = it.next();
                if ((p.pere != null && p.pere.equals(personne.pere)) || (p.mere != null && p.mere.equals(personne.mere))) {
                    System.out.println(p.prenom);
                }
            }
        }
    }

    public void afficherCousins(String prenom) {
        Personne personne = trouverPersonneParPrenom(prenom);
        if (personne != null) {
            for (Iterator<Personne> it = listePersonne.iterator(); it.hasNext();) {
                Personne p = it.next();
                if ((p.pere != null && p.pere.equals(personne.pere)) || (p.mere != null && p.mere.equals(personne.mere))) {
                    Set<Personne> onclesTantesPere = p.trouverFreresEtSoeurs();
                    for (Iterator<Personne> it2 = onclesTantesPere.iterator(); it2.hasNext();) {
                        Personne oncleTante = it2.next();
                        for (Iterator<Personne> it3 = oncleTante.enfants.iterator(); it3.hasNext();) {
                            Personne enfant = it3.next();
                            System.out.println(enfant.prenom);
                        }
                    }
                }
            }
        }
    }

    public void donnerLienDeParente(String prenom1, String prenom2) {
        Personne p1 = trouverPersonneParPrenom(prenom1);
        Personne p2 = trouverPersonneParPrenom(prenom2);

        if (p1 == null || p2 == null) {
            System.out.println("Une ou les deux personnes n'existent pas dans l'arbre.");
            return;
        }

        Queue<Personne> queue = new LinkedList<>();
        Map<Personne, Personne> parents = new HashMap<>();
        queue.add(p1);
        parents.put(p1, null);

        while (!queue.isEmpty()) {
            Personne current = queue.poll();
            if (current.equals(p2)) {
                break;
            }

            for (Iterator<Personne> it = current.enfants.iterator(); it.hasNext();) {
                Personne enfant = it.next();
                if (!parents.containsKey(enfant)) {
                    queue.add(enfant);
                    parents.put(enfant, current);
                }
            }
        }

        if (!parents.containsKey(p2)) {
            System.out.println("Aucun lien de parenté trouvé entre " + p1.prenom + " et " + p2.prenom + ".");
            return;
        }

        List<Personne> chemin = new ArrayList<>();
        for (Personne at = p2; at != null; at = parents.get(at)) {
            chemin.add(at);
        }
        Collections.reverse(chemin);

        StringBuilder lienDeParente = new StringBuilder();
        for (int i = 0; i < chemin.size(); i++) {
            Personne personne = chemin.get(i);
            lienDeParente.append(personne.prenom);
            if (i != chemin.size() - 1) {
                Personne suivant = chemin.get(i + 1);
                if (personne.pere == suivant || personne.mere == suivant) {
                    lienDeParente.append(" est parent de ");
                } else if (personne.enfants.contains(suivant)) {
                    lienDeParente.append(" est enfant de ");
                } else {
                    lienDeParente.append(" est lié à ");
                }
            }
        }
        System.out.println(lienDeParente.toString());
    }
}
