import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ArbreGenealogique extends JFrame {
    private JTree arbre;
    private DefaultMutableTreeNode racine;
    private JButton ajouterFils;
    private JButton ajouterFille;
    private JButton ajouterMari;
    private JButton ajouterMere;
    private JButton ajouterPere;
    private JTextField nomFils;
    private JTextField nomFille;
    private JTextField nomMari;
    private JTextField nomMere;
    private JTextField nomPere;

    public ArbreGenealogique() {
        // Créer la racine de l'arbre
        racine = new DefaultMutableTreeNode("Famille");

        // Créer l'arbre
        arbre = new JTree(racine);

        // Créer les boutons et les champs de texte
        ajouterFils = new JButton("Ajouter un fils");
        ajouterFille = new JButton("Ajouter une fille");
        ajouterMari = new JButton("Ajouter un mari");
        ajouterMere = new JButton("Ajouter une mère");
        ajouterPere = new JButton("Ajouter un père");

        nomFils = new JTextField(10);
        nomFille = new JTextField(10);
        nomMari = new JTextField(10);
        nomMere = new JTextField(10);
        nomPere = new JTextField(10);

        // Ajouter les boutons et les champs de texte à la fenêtre
        JPanel boutons = new JPanel();
        boutons.add(new JLabel("Nom du fils :"));
        boutons.add(nomFils);
        boutons.add(ajouterFils);

        boutons.add(new JLabel("Nom de la fille :"));
        boutons.add(nomFille);
        boutons.add(ajouterFille);

        boutons.add(new JLabel("Nom du mari :"));
        boutons.add(nomMari);
        boutons.add(ajouterMari);

        boutons.add(new JLabel("Nom de la mère :"));
        boutons.add(nomMere);
        boutons.add(ajouterMere);

        boutons.add(new JLabel("Nom du père :"));
        boutons.add(nomPere);
        boutons.add(ajouterPere);

        // Ajouter l'arbre et les boutons à la fenêtre
        Container contenu = getContentPane();
        contenu.setLayout(new BorderLayout());
        contenu.add(new JScrollPane(arbre), BorderLayout.CENTER);
        contenu.add(boutons, BorderLayout.SOUTH);

        // Ajouter des écouteurs d'événements aux boutons
        ajouterFils.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nom = nomFils.getText();
                if (!nom.isEmpty()) {
                    DefaultMutableTreeNode fils = new DefaultMutableTreeNode(nom);
                    racine.add(fils);
                    arbre.updateUI();
                    nomFils.setText("");
                }
            }
        });

        ajouterFille.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nom = nomFille.getText();
                if (!nom.isEmpty()) {
                    DefaultMutableTreeNode fille = new DefaultMutableTreeNode(nom);
                    racine.add(fille);
                    arbre.updateUI();
                    nomFille.setText("");
                }
            }
        });

        ajouterMari.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nom = nomMari.getText();
                if (!nom.isEmpty()) {
                    DefaultMutableTreeNode mari = new DefaultMutableTreeNode(nom);
                    racine.add(mari);
                    arbre.updateUI();
                    nomMari.setText("");
                }
            }
        });

        ajouterMere.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nom = nomMere.getText();
                if (!nom.isEmpty()) {
                    DefaultMutableTreeNode mere = new DefaultMutableTreeNode(nom);
                    racine.add(mere);
                    arbre.updateUI();
                    nomMere.setText("");
                }
            }
        });

        ajouterPere.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nom = nomPere.getText();
                if (!nom.isEmpty()) {
                    DefaultMutableTreeNode pere = new DefaultMutableTreeNode(nom);
                    racine.add(pere);
                    arbre.updateUI();
                    nomPere.setText("");
                }
            }
        });

        // Configurer la fenêtre
        setTitle("Arbre généalogique");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new ArbreGenealogique().setVisible(true);
            }
        });
    }
}