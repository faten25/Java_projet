public class Homme extends Personne {
    public Homme(String nom, int age, String prenom, char sexe, DateUtil dateNaissance, DateUtil dateMort) {
        super(nom, age, prenom, sexe, dateNaissance, dateMort);
    }

    public String toString() {
        return "Homme: " + getNom() + ", Âge: " + getAge();
    }
}