public class Femme extends Personne {
    public Femme(String nom, int age, String prenom, char sexe, DateUtil dateNaissance, DateUtil dateMort) {
        super(nom, age, prenom, sexe, dateNaissance, dateMort);
    }

    public String toString() {
        return "Femme: " + getNom() + ", Âge: " + getAge();
    }
}